/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROGRAM_SWITCH_CASE;

public class Bola {
    static String getluas() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private int Jari;
    
    public void setJari(int Jarijari )
    {
        this.Jari = Jarijari;
    }
    
    public int getJari()
    {
        return Jari;
    }
  
        public double hitungVolume()
        {
            double Volume;
            Volume=4/3 * 3.14 * (Jari * Jari * Jari);
            return Volume;
        }

    }
    
    
