/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROGRAM_SWITCH_CASE;


class Balok {
    private int Panjang;
    private int Lebar;
    private int Tinggi;
    
   public void setPanjang (int Panjang )
    {
        this.Panjang = Panjang;
    }
    public void setLebar (int lebar)
    {
        this.Lebar = lebar;
    }
    public void setTinggi(int tinggi)
    {
        this.Tinggi=tinggi;
    }
     public int getPanjang()
    {
        return Panjang;
    }
    public int getLebar()
    {
        return Lebar;       
    }
    public int getTinggi()
    {
        return Tinggi;       
    }
    
        public double hitungVolume()
        {
            double Volume;
            Volume= Panjang * Lebar * Tinggi;
            return Volume;
        }
   
}