
package PROGRAM_SWITCH_CASE;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class IOBangunDatar {
    public static void main(String[] args) {
        String pilih; 
        Scanner  Scan = new Scanner(System.in);
        BufferedReader datain = new BufferedReader (new InputStreamReader(System.in));
        Balok balok = new Balok();
        Kerucut kerucut = new Kerucut();
        Bola bola = new Bola();
        Limas limas = new Limas();
        Tabung tabung = new Tabung();
         try{
             
             System.out.println("SELAMAT DATANG DI PROGRAM BANGUN DATAR");
             System.out.println("1. HITUNG BALOK");
             System.out.println("2. HITUNG KRUCUT");
             System.out.println("3. HITUNG BOLA");
             System.out.println("4. HITUNG LIMAS");
             System.out.println("5. HITUNG TABUNG");
             pilih = Scan.nextLine();
             switch (pilih){
                 case "1":
                     System.out.println("Anda Memilih Balok");
                      System.out.println("inputkan Panjang");
                      String p = datain.readLine();
                      balok.setPanjang(Integer.parseInt (p));
        
                      System.out.println("inputkan Lebar");
                      String l = datain.readLine ();
                      balok.setLebar(Integer.parseInt (l));
        
                      System.out.println("inputkan tinggi");
                      String t = datain.readLine ();
                      balok.setTinggi(Integer.parseInt (t));
        
                      System.out.println("Panjang BALOK="+balok.getPanjang());
                      System.out.println("Lebar BALOK="+balok.getLebar ());
                      System.out.println("Tinggi BALOK="+balok.getTinggi ());
                      System.out.println("Volume BALOK="+balok.hitungVolume ());
                     break;
                 
                 case "2":
                     System.out.println("Anda menghitung Kerucut");
                      System.out.println("inputkan Jarijari");
                      String r = datain.readLine();
                      kerucut.setJari(Integer.parseInt (r));
            
                      System.out.println("inputkan Tinggi");
                      String T = datain.readLine();
                      kerucut.setTinggi(Integer.parseInt (T));
            
                      System.out.println("Jarijari KERUCUT="+kerucut.getJari());
                      System.out.println("Tinggi KERUCUT="+kerucut.getTinggi ());
                      System.out.println("Volume KERUCUT="+kerucut.hitungVolume ());
                      break;
                      
                 case "3":
                      System.out.println("Anda menghitung Bola");
                       System.out.println("Masukkan Jarijari");
                       String s = datain.readLine();
                       bola.setJari(Integer.parseInt (s));
           
            
                       System.out.println("Jarijari BOLA="+bola.getJari());
                       System.out.println("Volume BOLA="+bola.hitungVolume ());
                      break;
                      
                 case "4":
                      System.out.println(" Anda Menghitung limas");
                      System.out.println("masukkan nilai luas :");
                      String f = datain.readLine();
                      limas.setLuas(Integer.parseInt(f));
                      
                      System.out.println("masukkan nilai Tinggi :");
                      String g = datain.readLine();
                      limas.setTinggi(Integer.parseInt(g));
            
                      System.out.println("Luas Limas ="+limas.getLuas());
                      System.out.println("Tinggi Limas ="+limas.getTinggi());
                      System.out.println("volume Limas ="+limas.HitungVolume());
                      break;
                      
                  case "5" :
                      System.out.println("Anda Menghitung tabung");
                      System.out.println("masukkan nilai tinggi :");
                      String h = datain.readLine();
                      tabung.setTinggi(Integer.parseInt(h));
            
                      System.out.println("masukkan nilai jari-jari :");
                      String i = datain.readLine();
                      tabung.setJari(Integer.parseInt(i));
            
                      System.out.println("Tinggi Tabung ="+tabung.getTinggi());
                      System.out.println("Jari-jari Tabung ="+tabung.getJari());
                      System.out.println("Luas Tabung ="+tabung.HitungLuasAlas());
                      System.out.println("Volume Tabung ="+tabung.Hitungvolume());
                      System.out.println("Keliling Tabung ="+tabung.HitungKeliling());
                      break;          
             }
              }
              catch (IOException e)
              {
        
             
    }
    }
    
    }
    

