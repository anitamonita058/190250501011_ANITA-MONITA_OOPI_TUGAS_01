/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROGRAM_SWITCH_CASE;

public class Limas {
    private int Luas ;
    private int Tinggi;
    
    public void setLuas(int luas)
    {
     this.Luas = luas;   
    }
    public void setTinggi(int tinggi)
    {
        this.Tinggi = tinggi ;
    }
    public int getLuas()
    {
        return Luas;
    }
    public int getTinggi()
    {
        return Tinggi;
    }
    public double HitungVolume()
    {
        double volume;
        volume= Luas*Tinggi*1/3;
        return volume;
    }
    
}
