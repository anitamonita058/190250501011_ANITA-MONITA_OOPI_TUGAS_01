/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LIMAS;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author WIN -8
 */
public class coding {
     public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        LIMAS.proses LIMAS = new LIMAS.proses ();
        try 
        {
            System.out.println("Masukkan Nilai Luas Limas");
            String l = dataIn.readLine();
            LIMAS.setLuas(Integer.parseInt (l));
            
            System.out.println("Masukkan Nilai Tinggi Limas");
            String b = dataIn.readLine ();
            LIMAS.setTinggi(Integer.parseInt (b));
            
            System.out.println("Luas luas LIMAS="+LIMAS.getLuas());
            System.out.println("Tinggi LIMAS="+LIMAS.getTinggi ());
            System.out.println("Volume LIMAS="+LIMAS.hitungVolume ());
        }
       
        catch (IOException e)
        {
            System.out.println("Data yang di input salah");
        }
     }
    
    
}
