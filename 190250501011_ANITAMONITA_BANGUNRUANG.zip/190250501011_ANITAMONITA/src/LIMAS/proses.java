/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LIMAS;

/**
 *
 * @author WIN -8
 */
public class proses {
    private int Luas;
    private int Tinggi;
    
    public void setLuas (int luas)
    {
        this.Luas=luas;
    }
    public void setTinggi (int tinggi)
    {
        this.Tinggi=tinggi;
    }
    public int getLuas()
    {
        return Luas;
    }
    public int getTinggi()
    {
        return Tinggi;
    }
    public double hitungVolume()
    {
        double Volume;
        Volume= Luas * Tinggi * 1/3;
        return Volume;
    }    
    
    
}
