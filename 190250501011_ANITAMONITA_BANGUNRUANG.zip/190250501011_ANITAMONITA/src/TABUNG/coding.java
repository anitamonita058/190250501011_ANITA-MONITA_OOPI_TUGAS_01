/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TABUNG;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author WIN -8
 */
public class coding {
    public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        TABUNG.proses TABUNG = new TABUNG.proses ();
        try       
    {
        System.out.println("inputkan Jarijari");
        String r = dataIn.readLine();
        TABUNG.setJarijari(Integer.parseInt (r));
        
        System.out.println("inputkan tinggi");
        String t = dataIn.readLine ();
        TABUNG.setTinggi(Integer.parseInt (t));
        
        System.out.println("Jari jari TABUNG="+TABUNG.getJarijari());
        System.out.println("Tinggi TABUNG="+TABUNG.getTinggi ());
        System.out.println("Volume TABUNG="+TABUNG.hitungVolume ());
    }
        catch (IOException e)
    {
        System.out.println("Data yang di input salah");
        
    }
   }
}
    