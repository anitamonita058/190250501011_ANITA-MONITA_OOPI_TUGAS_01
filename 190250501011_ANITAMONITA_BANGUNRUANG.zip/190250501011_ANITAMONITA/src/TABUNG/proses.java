/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TABUNG;

/**
 *
 * @author WIN -8
 */
public class proses {
    private int Jari;
    private int Tinggi;
    
    public void setJarijari (int Jarijari )
    {
        this.Jari = Jarijari;
    }
    public void setTinggi (int tinggi)
    {
        this.Tinggi=tinggi;
    }
    public int getJarijari()
    {
        return Jari;
    }
    public int getTinggi()
    {
        return Tinggi;       
    }
        public double hitungVolume()
        {
            double Volume;
            Volume=3.14 * Jari * Jari * Tinggi;
            return Volume;
        }
            void settinggi (int parseint) {
                throw new UnsupportedOperationException("not support yet."); 
            }
   
    }

